package com.amanpvp.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;

public class AmanPvPClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HudRenderCallback.EVENT.register((MatrixStack matrices, float tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.options.hudHidden) return;

            int x = 6;
            int y = 6;
            int white = 0xFFFFFF;
            int red = 0xFF5555;

            client.textRenderer.drawWithShadow(matrices, "AMAN PVP", x, y, red);
            y += 11;
            client.textRenderer.drawWithShadow(
                matrices, "FPS: " + client.getCurrentFps(), x, y, white
            );
            y += 11;
            client.textRenderer.drawWithShadow(
                matrices,
                "XYZ: " + (int) client.player.getX() + " "
                    + (int) client.player.getY() + " "
                    + (int) client.player.getZ(),
                x, y, white
            );
        });
    }
}
