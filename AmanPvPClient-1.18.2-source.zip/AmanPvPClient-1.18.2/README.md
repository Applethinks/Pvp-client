# AmanPvP Client — Minecraft Java 1.18.2

A first playable starter for a custom Fabric client mod. It adds a small red **AMAN PVP** HUD with FPS and player coordinates.

## Build the JAR

You need a computer with Java 17 and Gradle (or add the Gradle wrapper).

1. Open this folder in IntelliJ IDEA, or install Gradle.
2. Run `gradle build` from this folder.
3. The mod JAR will be created in `build/libs/`.
4. Put the regular JAR (not the `-sources.jar`) into your Minecraft `mods` folder.
5. Use Minecraft **1.18.2**, Fabric Loader, and Fabric API **0.76.0+1.18.2**.

## Current features
- Custom branded HUD
- FPS counter
- XYZ coordinates
- Hides with Minecraft's F1 HUD toggle

## Next features
Keystrokes, CPS counter, armor HUD, potion effects, configurable HUD position, and a settings screen can be added in later versions.

## Notes
This is source code, not a precompiled/install-ready JAR. It has not been built or tested in Minecraft here. Build it with Java 17 so the output matches Minecraft 1.18.2.
